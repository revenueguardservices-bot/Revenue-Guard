"use client";

import { useState } from "react";

const STEPS = [
  {
    step: 1,
    title: "We review your property and pricing rules",
    desc: "We look at your listings, calendar, and any rules you already use.",
  },
  {
    step: 2,
    title: "We connect your booking data and activate dynamic pricing",
    desc: "Secure connection to your channel. No manual exports.",
  },
  {
    step: 3,
    title: "Prices adjust automatically as demand changes",
    desc: "Nightly rates update based on real signals — you don't lift a finger.",
  },
  {
    step: 4,
    title: "You receive a monthly performance summary",
    desc: "Insights and recommendations in plain English, every month.",
  },
];

export default function HowItWorksAccordion() {
  const [activeStep, setActiveStep] = useState<number | null>(null);

  return (
    <div
      className="flex gap-2 md:gap-3 w-full rounded-2xl overflow-hidden min-h-[280px] md:min-h-[320px]"
      role="list"
      aria-label="How it works steps"
    >
      {STEPS.map((item) => {
        const isActive = activeStep === item.step;
        return (
          <div
            key={item.step}
            role="listitem"
            className={`relative flex-shrink-0 overflow-hidden rounded-xl transition-all duration-500 ease-out cursor-pointer border-2 ${
              isActive
                ? "flex-[2] min-w-[200px] md:min-w-[320px] border-accent-cyan bg-[#ecfdfa] shadow-xl shadow-accent-cyan/15"
                : "flex-1 min-w-[72px] md:min-w-[88px] border-neutral-200 bg-white hover:border-accent-cyan/50 hover:bg-[#f0fdfa]"
            }`}
            onMouseEnter={() => setActiveStep(item.step)}
            onMouseLeave={() => setActiveStep(null)}
            onFocus={() => setActiveStep(item.step)}
            onBlur={() => setActiveStep(null)}
            tabIndex={0}
          >
            <div className="absolute inset-0 p-4 md:p-6 flex flex-col justify-center">
              <div className="flex items-start gap-3 md:gap-4">
                <div
                  className={`flex-shrink-0 w-11 h-11 md:w-12 md:h-12 rounded-xl flex items-center justify-center font-display font-bold text-base md:text-lg transition-colors duration-300 ${
                    isActive ? "bg-accent-cyan text-white shadow-md" : "bg-accent-cyan/20 text-accent-teal"
                  }`}
                >
                  {item.step}
                </div>
                <div className={`min-w-0 flex-1 transition-all duration-300 ${isActive ? "opacity-100" : "opacity-0 md:opacity-90"}`}>
                  <h3 className="font-display font-semibold text-primary-900 text-sm md:text-lg leading-tight">
                    {item.title}
                  </h3>
                  <p className="mt-1.5 md:mt-2 text-xs md:text-sm text-neutral-600 leading-relaxed">
                    {item.desc}
                  </p>
                </div>
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
