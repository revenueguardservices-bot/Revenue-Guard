"use client";

import { useState } from "react";

type LogoProps = {
  className?: string;
  width?: number;
  height?: number;
};

export default function Logo({ className = "", width = 32, height = 32 }: LogoProps) {
  const [failed, setFailed] = useState(false);

  // Use dedicated logo file; if it fails, render nothing so "Revenue Guard LTD" text still shows and page never breaks
  if (failed) return null;

  return (
    <img
      src="/logo-rev-guard.png"
      alt="Revenue Guard"
      width={width}
      height={height}
      className={className}
      onError={() => setFailed(true)}
      loading="lazy"
    />
  );
}
