"use client";

import { useEffect, useState } from "react";

const STORAGE_KEY = "revenue-guard-cookie-consent";

type CookieConsentProps = {
  onOpenCookiePolicy: () => void;
};

export default function CookieConsent({ onOpenCookiePolicy }: CookieConsentProps) {
  const [showBanner, setShowBanner] = useState(false);

  useEffect(() => {
    const stored = typeof window !== "undefined" ? localStorage.getItem(STORAGE_KEY) : null;
    if (!stored) setShowBanner(true);
  }, []);

  const save = (value: string) => {
    if (typeof window !== "undefined") {
      localStorage.setItem(STORAGE_KEY, value);
    }
    setShowBanner(false);
  };

  const handleAccept = () => save("accept");
  const handleReject = () => save("reject");
  const handleManage = () => {
    save("preferences");
    onOpenCookiePolicy();
  };

  if (!showBanner) return null;

  return (
    <div
      role="dialog"
      aria-label="Cookie consent"
      className="fixed bottom-0 left-0 right-0 z-[80] bg-white border-t border-[var(--border)] shadow-lg px-4 py-4 md:px-6 md:py-5"
    >
      <div className="container mx-auto max-w-4xl flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
        <p className="text-sm text-[var(--muted)] flex-1">
          We use cookies to ensure our website works properly and to understand how it&apos;s used. This helps us improve our services.{" "}
          <button
            type="button"
            onClick={onOpenCookiePolicy}
            className="text-[var(--primary)] font-medium hover:underline theme-focus-ring"
          >
            Read our Cookie Policy
          </button>
        </p>
        <div className="flex flex-wrap items-center gap-2 sm:gap-3 shrink-0">
          <button
            type="button"
            onClick={handleAccept}
            className="px-4 py-2.5 rounded-xl text-sm font-semibold bg-[var(--primary)] text-white hover:bg-[var(--primary-700)] transition-colors theme-focus-ring"
          >
            Accept all cookies
          </button>
          <button
            type="button"
            onClick={handleReject}
            className="px-4 py-2.5 rounded-xl text-sm font-medium border border-[var(--border)] bg-white text-[var(--foreground)] hover:bg-[var(--primary-50)] transition-colors theme-focus-ring"
          >
            Reject non-essential cookies
          </button>
          <button
            type="button"
            onClick={handleManage}
            className="px-4 py-2.5 rounded-xl text-sm font-medium text-[var(--primary)] hover:underline theme-focus-ring"
          >
            Manage preferences
          </button>
        </div>
      </div>
    </div>
  );
}
