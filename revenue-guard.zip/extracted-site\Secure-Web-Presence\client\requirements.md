## Packages
framer-motion | Smooth animations for sections and modals
lucide-react | Icons for features and UI elements
react-hook-form | Form handling for the inquiry modal
zod | Schema validation
@hookform/resolvers | Zod resolver for react-hook-form

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  sans: ["Inter", "sans-serif"],
  display: ["Cabinet Grotesk", "Inter", "sans-serif"],
}
