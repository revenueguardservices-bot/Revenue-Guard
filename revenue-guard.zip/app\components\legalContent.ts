export const TERMS_TITLE = "Terms of Service";
export const TERMS_UPDATED = "02/02/2026";
export const TERMS_FOOTER =
  "Revenue Guard provides managed pricing services and performance insights. We do not provide financial, tax, or legal advice, and we do not handle client funds.";

export const termsSections = [
  {
    heading: "1. Introduction",
    body: "These Terms of Service (“Terms”) govern your use of the Revenue Guard website and services. Revenue Guard (“we”, “us”, “our”) provides managed dynamic pricing and performance reporting services for holiday let and short-stay accommodation businesses. By accessing our website or using our services, you agree to these Terms.",
  },
  {
    heading: "2. Our Services",
    body: "Revenue Guard provides: Managed dynamic pricing configuration; Ongoing pricing optimisation within agreed parameters; Monthly performance summaries and recommendations. Our services are advisory and operational in nature. We do not guarantee any specific level of revenue, occupancy, profit, or performance. While Revenue Guard uses data-driven methodologies and automation to inform pricing decisions, all outcomes are influenced by external market factors beyond our control, including market demand, seasonality, competition, property quality, and guest behaviour. As such, Revenue Guard makes no representations or guarantees regarding revenue, occupancy, or financial performance. Revenue Guard does not collect, hold, process, or handle client funds, payments, or guest transactions. All booking payments and financial transactions remain under the sole control of the client and relevant booking platforms.",
  },
  {
    heading: "3. Eligibility",
    body: "You must be at least 18 years old and legally capable of entering into contracts to use our services. If you are using Revenue Guard on behalf of a business, you confirm that you have authority to bind that business to these Terms.",
  },
  {
    heading: "4. Client Responsibilities",
    body: "You agree to: Provide accurate and up-to-date information about your properties; Maintain ownership or authorisation to manage the listed properties; Review pricing guardrails and approve initial configurations; Notify us promptly of material changes that may affect pricing. You remain responsible for: Final pricing approval; Listing content and availability; Compliance with platform rules (e.g. Airbnb, booking platforms); Local laws and regulations relating to your properties.",
  },
  {
    heading: "5. Pricing & Payments",
    body: "Fees are charged on a monthly basis as agreed. Payments are due in advance of each billing period. No long-term contracts unless explicitly agreed. You may cancel at any time with effect from the next billing cycle. Failure to pay may result in suspension or termination of services.",
  },
  {
    heading: "6. No Financial or Legal Advice",
    body: "Revenue Guard does not provide financial, tax, or legal advice. Any information or recommendations provided are for general business purposes only. You should consult appropriate professionals before making financial or legal decisions.",
  },
  {
    heading: "7. Limitation of Liability",
    body: "To the maximum extent permitted by law: We are not liable for indirect, incidental, or consequential losses; We are not responsible for losses caused by platform outages or third-party systems; Revenue Guard's total aggregate liability arising from or relating to the services shall not exceed the total fees paid by the client to Revenue Guard in the three (3) months preceding the claim. Nothing in these Terms limits liability for fraud or death or personal injury caused by negligence.",
  },
  {
    heading: "8. Intellectual Property",
    body: "All content, materials, reports, and branding provided by Revenue Guard remain our intellectual property unless otherwise agreed. You may not reproduce, distribute, or resell our materials without written permission.",
  },
  {
    heading: "9. Termination",
    body: "Either party may terminate services at any time by providing written notice. Upon termination: Access to services will end; Outstanding fees remain payable; Confidentiality obligations continue.",
  },
  {
    heading: "10. Confidentiality",
    body: "Both parties agree to keep confidential any non-public information shared during the course of the service. This obligation survives termination.",
  },
  {
    heading: "11. Changes to These Terms",
    body: "We may update these Terms from time to time. The latest version will always be available on our website.",
  },
  {
    heading: "12. Governing Law",
    body: "These Terms are governed by the laws of England and Wales. Any disputes will be subject to the exclusive jurisdiction of the courts of England and Wales.",
  },
  {
    heading: "13. Client Control & Approval",
    body: "Clients retain ultimate control over their pricing strategy. Initial pricing guardrails and configurations are approved by the client prior to activation. Clients may request adjustments or suspension of pricing activity at any time.",
  },
];

export const PRIVACY_TITLE = "Privacy Policy";
export const PRIVACY_UPDATED = "02/02/2026";

export const privacySections = [
  {
    heading: "1. Introduction",
    body: "Revenue Guard is committed to protecting your privacy. This Privacy Policy explains how we collect, use, store, and protect your personal data in accordance with the UK General Data Protection Regulation (UK GDPR) and the Data Protection Act 2018. Revenue Guard Ltd is registered with the UK Information Commissioner's Office (ICO) for data protection purposes.",
  },
  {
    heading: "2. Information We Collect",
    body: "We may collect the following information: Personal Information — Name, Email address, Business name, Contact details. Business & Property Information — Property details, Pricing data, Booking and availability data. Technical Information — IP address, Browser type, Website usage data.",
  },
  {
    heading: "3. How We Use Your Information",
    body: "We use your data to: Provide and manage our services; Configure and optimise pricing; Produce monthly performance summaries; Communicate with you; Improve our website and services; Comply with legal obligations. Revenue Guard does not sell personal or business data to third parties.",
  },
  {
    heading: "4. Legal Basis for Processing",
    body: "We process your data based on: Performance of a contract; Legitimate business interests; Legal obligations; Your consent (where required).",
  },
  {
    heading: "5. Data Sharing",
    body: "We may share data with: Technology providers used to deliver our services; Professional advisers (e.g. accountants, legal advisers); Regulatory authorities where legally required. All third parties are required to protect your data.",
  },
  {
    heading: "6. Data Storage & Security",
    body: "We take appropriate technical and organisational measures to protect your data against: Unauthorised access; Loss; Misuse. Data is only retained for as long as necessary.",
  },
  {
    heading: "7. Data Hosting & Processing",
    body: "Revenue Guard's website is hosted by Hostinger. Data may be processed and stored on secure servers operated by Hostinger and other third-party service providers necessary for the delivery of our services. All such providers are required to comply with applicable data protection laws and maintain appropriate security measures.",
  },
  {
    heading: "8. Your Rights",
    body: "You have the right to: Access your personal data; Request correction or deletion; Restrict or object to processing; Request data portability; Withdraw consent at any time. To exercise these rights, contact us using the details below.",
  },
  {
    heading: "9. Cookies",
    body: "Our website may use cookies to improve functionality and analyse usage. You can manage cookie preferences through your browser settings.",
  },
  {
    heading: "10. Third-Party Links",
    body: "Our website may contain links to third-party websites. We are not responsible for their privacy practices.",
  },
  {
    heading: "11. Changes to This Policy",
    body: "We may update this Privacy Policy from time to time. The latest version will always be available on our website.",
  },
  {
    heading: "12. Contact Information",
    body: "For privacy or data-related enquiries, contact: revenueguardservices@gmail.com. We use cookies to ensure our website works properly and to understand how it's used. This helps us improve our services. You can accept all cookies, reject non-essential cookies, or manage your preferences.",
  },
];

export const COOKIE_TITLE = "Cookie Policy";
export const COOKIE_UPDATED = "02/02/2026";

export const cookieSections = [
  {
    heading: "What are cookies?",
    body: "Cookies are small text files that are placed on your device when you visit a website. They are widely used to make websites work efficiently, improve user experience, and provide information to website owners.",
  },
  {
    heading: "How we use cookies",
    body: "We use cookies to: Ensure the website functions correctly; Understand how visitors use our website; Improve website performance and usability. We do not use cookies to identify you personally or to sell data to third parties.",
  },
  {
    heading: "Types of cookies we use",
    body: "1. Strictly Necessary Cookies — These cookies are essential for the website to function properly and cannot be switched off in our systems. Examples: Security cookies, Session management cookies. 2. Analytics / Performance Cookies — These cookies help us understand how visitors interact with our website so we can improve it. Examples: Pages visited, Time spent on pages, Traffic sources. We may use tools such as Google Analytics for this purpose. All data collected is aggregated and anonymised where possible.",
  },
  {
    heading: "Managing cookies",
    body: "You can control or delete cookies through your browser settings at any time. Please note that disabling certain cookies may affect how the website functions. For more information on managing cookies, visit your browser's help pages.",
  },
  {
    heading: "Third-party cookies",
    body: "Some cookies may be set by third-party services we use (such as analytics providers). We do not control these cookies directly, but they are used only for the purposes described above.",
  },
  {
    heading: "Changes to this policy",
    body: "We may update this Cookie Policy from time to time to reflect changes in law or how we use cookies. Any updates will be posted on this page.",
  },
  {
    heading: "Contact us",
    body: "If you have any questions about this Cookie Policy or how we use cookies, please contact us at: Email: revenueguardservices@gmail.com. Company: Revenue Guard Ltd.",
  },
];
