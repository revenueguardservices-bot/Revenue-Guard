"use client";

import { useState } from "react";
import FreeReviewModal from "./FreeReviewModal";
import FadeInSection from "./FadeInSection";
import Logo from "./Logo";
import CookieConsent from "./CookieConsent";
import LegalPopout, { type LegalDocType } from "./LegalPopout";

function CheckIcon({ className = "w-4 h-4" }: { className?: string }) {
  return (
    <svg className={className} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    </svg>
  );
}

export default function LandingPage() {
  const [showModal, setShowModal] = useState(false);
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [legalPopout, setLegalPopout] = useState<LegalDocType | null>(null);
  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  const navLinks = [
    { href: "#hero", label: "Home" },
    { href: "#how-it-works", label: "How It Works" },
    { href: "#pricing", label: "Pricing" },
    { href: "#why-different", label: "About" },
    { href: "#footer", label: "Contact" },
  ];

  return (
    <div className="min-h-screen bg-[var(--background)] overflow-x-hidden pb-28">
      <FreeReviewModal isOpen={showModal} onClose={closeModal} />
      <CookieConsent onOpenCookiePolicy={() => setLegalPopout("cookies")} />
      <LegalPopout type={legalPopout} onClose={() => setLegalPopout(null)} />

      {/* Navigation — logo-driven, clean */}
      <nav className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-[var(--border)]">
        <div className="container mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <a href="#" className="flex items-center gap-2.5 text-[var(--foreground)] no-underline" onClick={() => setMobileMenuOpen(false)}>
            <Logo className="h-10 w-auto shrink-0" width={40} height={40} />
            <span className="font-bold text-xl tracking-tight">Revenue Guard LTD</span>
          </a>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-[var(--muted)]">
            {navLinks.map((link) => (
              <a key={link.href} href={link.href} className="hover:text-[var(--primary)] transition-colors">{link.label}</a>
            ))}
          </div>
          <div className="flex items-center gap-3">
            <button
              type="button"
              onClick={openModal}
              className="rounded-xl bg-[var(--primary)] px-5 py-2.5 text-sm font-semibold text-white shadow-md shadow-[var(--primary)]/20 hover:bg-[var(--primary-700)] transition-all duration-300 hover:-translate-y-0.5 theme-focus-ring hidden sm:inline-flex"
            >
              Get a Free Pricing Review
            </button>
            <button
              type="button"
              onClick={() => setMobileMenuOpen((o) => !o)}
              className="md:hidden p-2 rounded-lg text-[var(--muted)] hover:text-[var(--foreground)] hover:bg-[var(--primary-50)] transition-colors theme-focus-ring"
              aria-label={mobileMenuOpen ? "Close menu" : "Open menu"}
              aria-expanded={mobileMenuOpen}
            >
              {mobileMenuOpen ? (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" /></svg>
              ) : (
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" /></svg>
              )}
            </button>
          </div>
        </div>
        {/* Mobile menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-[var(--border)] bg-white/95 backdrop-blur-md">
            <div className="container mx-auto px-4 py-4 flex flex-col gap-2">
              {navLinks.map((link) => (
                <a
                  key={link.href}
                  href={link.href}
                  className="py-3 px-4 rounded-lg text-[var(--foreground)] font-medium hover:bg-[var(--primary-50)] hover:text-[var(--primary)] transition-colors theme-focus-ring"
                  onClick={() => setMobileMenuOpen(false)}
                >
                  {link.label}
                </a>
              ))}
              <button
                type="button"
                onClick={() => { openModal(); setMobileMenuOpen(false); }}
                className="mt-2 py-3 px-4 rounded-xl bg-[var(--primary)] text-white font-semibold text-center hover:bg-[var(--primary-700)] transition-colors theme-focus-ring sm:hidden"
              >
                Get a Free Pricing Review
              </button>
            </div>
          </div>
        )}
      </nav>

      {/* HERO SECTION — exact copy from reference */}
      <section id="hero" className="pt-32 pb-20 md:pt-40 md:pb-32 px-4 relative overflow-hidden gradient-mesh">
        <div className="container mx-auto max-w-6xl relative z-10">
          <FadeInSection>
            <div className="max-w-4xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-[var(--foreground)] leading-[1.1] text-balance">
                Smarter pricing for your holiday lets — with clear monthly results
              </h1>
              <p className="mt-6 text-xl md:text-2xl text-[var(--muted)] leading-relaxed text-balance max-w-2xl mx-auto">
                We manage your pricing strategy and send you a simple monthly report showing exactly what it earned you.
              </p>
              <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
                <button
                  type="button"
                  onClick={openModal}
                  className="h-14 px-8 text-lg rounded-xl font-semibold bg-[var(--primary)] text-white shadow-xl shadow-[var(--primary)]/20 hover:bg-[var(--primary-700)] hover:-translate-y-0.5 transition-all duration-300 theme-btn-primary theme-focus-ring"
                >
                  Get a Free Pricing Review
                </button>
                <a
                  href="#how-it-works"
                  className="h-14 px-8 text-lg rounded-xl font-medium border-2 border-[var(--border)] bg-white text-[var(--foreground)] hover:bg-[var(--primary-50)] hover:border-[var(--primary-200)] inline-flex items-center justify-center transition-all duration-300 theme-focus-ring"
                >
                  How It Works
                </a>
              </div>
            </div>
          </FadeInSection>
        </div>
      </section>

      {/* WHO IT'S FOR */}
      <section className="py-20 md:py-24 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-4 text-center">
              Who it&apos;s for.
            </h2>
            <p className="text-lg text-[var(--muted)] text-center mb-12 max-w-2xl mx-auto">
              Holiday let and small Airbnb owners. Ideal for hosts with 2–20 properties who want control, clarity, and less busywork adjusting prices or relying on unclear tools.
            </p>
            <div className="grid md:grid-cols-3 gap-6">
              {[
                { title: "No constant price tweaking", desc: "We handle adjustments so you don't have to." },
                { title: "No black-box systems", desc: "Clear explanations, not unexplained algorithms." },
                { title: "Clear oversight and control", desc: "You see what changed and why, every month." },
              ].map((item, i) => (
                <div key={i} className="theme-card p-6 text-center">
                  <h3 className="font-semibold text-[var(--foreground)] mb-2">{item.title}</h3>
                  <p className="text-sm text-[var(--muted)]">{item.desc}</p>
                </div>
              ))}
            </div>
          </FadeInSection>
        </div>
      </section>

      {/* THE PROBLEM */}
      <section className="py-20 md:py-24 bg-[var(--primary-50)]">
        <div className="container mx-auto px-4 max-w-4xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-4 text-center">
              The problem.
            </h2>
            <p className="text-lg text-[var(--muted)] text-center max-w-2xl mx-auto">
              Peak dates may be underpriced, quiet periods overpriced, tedious adjustments, and no way to know if price changes are helping your income.
            </p>
          </FadeInSection>
        </div>
      </section>

      {/* OUR SOLUTION */}
      <section className="py-20 md:py-24 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-4 text-center">
              Our solution.
            </h2>
            <p className="text-lg text-[var(--muted)] text-center mb-8 max-w-2xl mx-auto">
              We manage your pricing using demand, seasonality, and booking trends—so you never miss out or overcharge. Minimums and maximums always protected and you get a clear monthly report showing what changed and why.
            </p>
            <div className="space-y-6 max-w-2xl mx-auto">
              <div className="theme-card p-6">
                <h3 className="font-semibold text-[var(--foreground)] mb-2">No black boxes.</h3>
                <p className="text-[var(--muted)]">
                  Managed service. No confusing graphs or unexplained price shifts. Every month, you see what worked and why, with a simple summary in plain English.
                </p>
              </div>
              <div className="theme-card p-6">
                <h3 className="font-semibold text-[var(--foreground)] mb-2">Compared to algorithms.</h3>
                <p className="text-[var(--muted)]">
                  We offer a more transparent approach than automated tools: prices are set by people and refined by technology, with insight you control.
                </p>
              </div>
            </div>
          </FadeInSection>
        </div>
      </section>

      {/* HOW IT WORKS — 4-step visual layout */}
      <section id="how-it-works" className="py-20 md:py-24 bg-[var(--primary-50)]">
        <div className="container mx-auto px-4 max-w-5xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-12 text-center">
              How It Works
            </h2>
          </FadeInSection>
          <div className="grid md:grid-cols-4 gap-6 md:gap-8">
            {[
              { step: "Step 1", title: "Review rules", subtitle: "Review property and pricing rules" },
              { step: "Step 2", title: "Connect data", subtitle: "Connect booking data and activate pricing" },
              { step: "Step 3", title: "Adjust prices", subtitle: "Prices adjust automatically" },
              { step: "Step 4", title: "Monthly summary", subtitle: "Monthly performance summary with insights" },
            ].map((item, i) => (
              <FadeInSection key={i} delay={i * 80}>
                <div className="theme-card p-6 text-center relative">
                  <span className="text-sm font-bold text-[var(--primary)] uppercase tracking-wider">{item.step}</span>
                  <h3 className="text-xl font-bold text-[var(--foreground)] mt-2 mb-1">{item.title}</h3>
                  <p className="text-sm text-[var(--muted)]">{item.subtitle}</p>
                </div>
              </FadeInSection>
            ))}
          </div>
          <FadeInSection delay={200}>
            <div className="mt-12 grid grid-cols-2 md:grid-cols-4 gap-4 text-center">
              {["Auto-optimise", "Monthly insights", "Best dates", "Action tips"].map((label, i) => (
                <div key={i} className="flex items-center justify-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-[var(--accent-orange)]" aria-hidden />
                  <span className="text-sm font-medium text-[var(--muted)]">{label}</span>
                </div>
              ))}
            </div>
          </FadeInSection>
        </div>
      </section>

      {/* WHAT YOU GET EACH MONTH */}
      <section className="py-20 md:py-24 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-8 text-center">
              What you get each month
            </h2>
            <div className="grid md:grid-cols-2 gap-6">
              {[
                "Automated price optimisation",
                "Occupancy and revenue insights",
                "Best and worst performing dates",
                "Clear recommendations",
                "Optional monthly call on higher plans",
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-[var(--accent-cyan)]/20 flex items-center justify-center flex-shrink-0">
                    <CheckIcon className="w-4 h-4 text-[var(--accent-teal)]" />
                  </div>
                  <span className="text-[var(--foreground)] font-medium">{item}</span>
                </div>
              ))}
            </div>
          </FadeInSection>
        </div>
      </section>

      {/* PRICING — exact copy: Starter £199, Growth £399, Pro £699 */}
      <section id="pricing" className="py-20 md:py-24 bg-[var(--primary-50)]">
        <div className="container mx-auto px-4 max-w-6xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-4 text-center">
              Pricing
            </h2>
            <p className="text-lg text-[var(--muted)] text-center mb-12">
              No hidden fees. No surprises.
            </p>
          </FadeInSection>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { name: "Starter", price: "£199", period: "/month", for: "For 1–2 properties", features: ["Dynamic pricing", "Monthly performance report"] },
              { name: "Growth", price: "£399", period: "/month", for: "3–5 properties", features: ["Includes Starter features", "Monthly review call"], popular: true },
              { name: "Pro", price: "£699", period: "/month", for: "6–15 properties", features: ["Full portfolio pricing", "Priority support"] },
            ].map((plan, i) => (
              <FadeInSection key={i} delay={i * 60}>
                <div className={`theme-card p-8 h-full flex flex-col ${plan.popular ? "ring-2 ring-[var(--primary)] shadow-lg" : ""}`}>
                  {plan.popular && (
                    <span className="text-xs font-bold text-[var(--primary)] uppercase tracking-wider mb-2">Popular</span>
                  )}
                  <h3 className="text-xl font-bold text-[var(--foreground)]">{plan.name}</h3>
                  <div className="mt-4 flex items-baseline gap-1">
                    <span className="text-4xl font-bold text-[var(--foreground)]">{plan.price}</span>
                    <span className="text-[var(--muted)]">{plan.period}</span>
                  </div>
                  <p className="text-sm text-[var(--muted)] mt-1">{plan.for}</p>
                  <ul className="mt-6 space-y-3 flex-1">
                    {plan.features.map((f, j) => (
                      <li key={j} className="flex items-center gap-2 text-sm text-[var(--foreground)]">
                        <CheckIcon className="w-4 h-4 text-[var(--primary)] flex-shrink-0" />
                        {f}
                      </li>
                    ))}
                  </ul>
                  <button
                    type="button"
                    onClick={openModal}
                    className="mt-6 w-full py-3.5 rounded-xl font-semibold bg-[var(--primary)] text-white hover:bg-[var(--primary-700)] transition-all duration-300 hover:-translate-y-0.5 theme-focus-ring"
                  >
                    Start Free Review
                  </button>
                </div>
              </FadeInSection>
            ))}
          </div>
          <FadeInSection delay={120}>
            <p className="mt-8 text-center text-sm text-[var(--muted)]">
              No long-term contracts. Cancel anytime.
            </p>
          </FadeInSection>
        </div>
      </section>

      {/* WHY THIS IS DIFFERENT */}
      <section id="why-different" className="py-20 md:py-24 bg-white">
        <div className="container mx-auto px-4 max-w-4xl">
          <FadeInSection>
            <h2 className="text-2xl md:text-3xl font-bold text-[var(--foreground)] mb-6 text-center">
              Why this is different
            </h2>
            <p className="text-lg text-[var(--muted)] text-center max-w-3xl mx-auto leading-relaxed">
              This is a managed pricing service, not just another tool — we explain our actions and you stay in control every step. No cryptic dashboards, no &apos;set and forget&apos; pricing — just clear, expert support.
            </p>
            <p className="mt-6 text-lg text-[var(--muted)] text-center max-w-3xl mx-auto leading-relaxed">
              You get transparency, human oversight, and a process built specifically for holiday lets, not hotels. Every detail is designed to deliver real results — with zero confusion.
            </p>
          </FadeInSection>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="py-20 md:py-24 bg-[var(--primary-800)] text-white relative overflow-hidden">
        <div className="absolute inset-0 opacity-20 gradient-mesh" />
        <div className="container mx-auto px-4 max-w-3xl relative z-10 text-center">
          <FadeInSection>
            <h2 className="text-3xl md:text-4xl font-bold mb-6">
              See if your pricing could be working harder
            </h2>
            <p className="text-lg text-white/80 mb-8">
              No obligation. No pressure.
            </p>
            <button
              type="button"
              onClick={openModal}
              className="h-14 px-10 text-lg font-semibold bg-white text-[var(--primary)] rounded-xl shadow-xl hover:bg-[var(--primary-50)] hover:-translate-y-0.5 transition-all duration-300 theme-focus-ring"
            >
              Request a Free Pricing Review
            </button>
          </FadeInSection>
        </div>
      </section>

      {/* FOOTER */}
      <footer id="footer" className="py-12 md:py-16 bg-white border-t border-[var(--border)]">
        <div className="container mx-auto px-4 max-w-6xl">
          <FadeInSection>
            <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-8">
              <div className="flex items-center gap-2.5">
                <Logo className="h-10 w-auto shrink-0" width={40} height={40} />
                <span className="font-bold text-xl tracking-tight text-[var(--foreground)]">Revenue Guard LTD</span>
              </div>
              <p className="text-sm text-[var(--muted)] max-w-md">
                Premium pricing service for holiday lets. No contracts. Cancel anytime.
              </p>
            </div>
            <div className="mt-8 pt-8 border-t border-[var(--border)] flex flex-col sm:flex-row sm:items-center sm:justify-between gap-6">
              <div className="flex flex-wrap gap-6 text-sm">
                <a href="#hero" className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors">Home</a>
                <a href="#how-it-works" className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors">How It Works</a>
                <a href="#pricing" className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors">Pricing</a>
                <a href="#why-different" className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors">About</a>
                <a href="mailto:revenueguardservices@gmail.com" className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors">Contact</a>
                <button
                  type="button"
                  onClick={() => setLegalPopout("terms")}
                  className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors text-left"
                >
                  Terms of Service
                </button>
                <button
                  type="button"
                  onClick={() => setLegalPopout("privacy")}
                  className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors text-left"
                >
                  Privacy Policy
                </button>
                <button
                  type="button"
                  onClick={() => setLegalPopout("cookies")}
                  className="text-[var(--muted)] hover:text-[var(--primary)] transition-colors text-left"
                >
                  Read our Cookie Policy
                </button>
              </div>
              <div className="flex flex-wrap items-center gap-4 text-sm">
                <span className="text-[var(--muted)]">Email</span>
                <a href="mailto:revenueguardservices@gmail.com" className="font-medium text-[var(--primary)] hover:underline">
                  revenueguardservices@gmail.com
                </a>
                <button
                  type="button"
                  onClick={openModal}
                  className="text-[var(--primary)] font-medium hover:underline"
                >
                  Request Review
                </button>
              </div>
            </div>
            <p className="mt-8 text-sm text-[var(--muted)]">
              © {new Date().getFullYear()} Revenue Guard. All rights reserved.
            </p>
            <p className="mt-2 text-xs text-[var(--muted)] max-w-xl">
              Revenue Guard provides managed pricing services and performance insights. We do not provide financial, tax, or legal advice, and we do not handle client funds.
            </p>
            <div className="mt-8 pt-8 border-t border-[var(--border)] max-w-2xl">
              <h3 className="text-sm font-semibold text-[var(--foreground)] mb-3">
                Website GDPR / Privacy Summary
              </h3>
              <p className="text-xs text-[var(--muted)] leading-relaxed mb-3">
                Revenue Guard is committed to protecting personal data and complying with UK GDPR.
              </p>
              <p className="text-xs text-[var(--muted)] leading-relaxed mb-3">
                We process personal data only where necessary to deliver our services, including pricing analysis, performance reporting, and review summaries for holiday let properties. This may include limited booking and review data from third-party platforms.
              </p>
              <p className="text-xs text-[var(--muted)] leading-relaxed mb-3">
                We do not sell personal data or use it for unsolicited marketing. Data is handled securely and accessed only where required to provide our services.
              </p>
              <p className="text-xs text-[var(--muted)] leading-relaxed mb-3">
                Clients remain the Data Controller. Revenue Guard acts as a Data Processor and processes data solely on client instructions, as set out in our Data Processing Agreement.
              </p>
              <p className="text-xs text-[var(--muted)] leading-relaxed mb-2">
                For full details of how we handle personal data, please see our{" "}
                <button
                  type="button"
                  onClick={() => setLegalPopout("privacy")}
                  className="text-[var(--primary)] font-medium hover:underline theme-focus-ring"
                >
                  Privacy Policy
                </button>
                .
              </p>
              <p className="text-xs text-[var(--muted)]">
                Contact:{" "}
                <a href="mailto:revenueguardservices@gmail.com" className="text-[var(--primary)] font-medium hover:underline">
                  revenueguardservices@gmail.com
                </a>
              </p>
            </div>
          </FadeInSection>
        </div>
      </footer>
    </div>
  );
}
