import { motion } from "framer-motion";
import { InquiryDialog } from "@/components/InquiryDialog";
import { Button } from "@/components/ui/button";
import { 
  Check, 
  TrendingUp, 
  Clock, 
  LineChart, 
  ShieldCheck, 
  BarChart3, 
  LayoutDashboard,
  Zap,
  ArrowRight
} from "lucide-react";
import {
  Card,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";

// Animation variants
const fadeIn = {
  initial: { opacity: 0, y: 20 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 }
};

const staggerContainer = {
  animate: {
    transition: {
      staggerChildren: 0.1
    }
  }
};

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-slate-50 overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-white/80 backdrop-blur-md border-b border-slate-200">
        <div className="container mx-auto px-4 md:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center">
              <TrendingUp className="text-white w-5 h-5" />
            </div>
            <span className="font-bold text-xl text-slate-900 tracking-tight">Revenue Guard</span>
          </div>
          <div className="hidden md:flex items-center gap-8 text-sm font-medium text-slate-600">
            <a href="#problem" className="hover:text-primary transition-colors">Why It Matters</a>
            <a href="#how-it-works" className="hover:text-primary transition-colors">How It Works</a>
            <a href="#pricing" className="hover:text-primary transition-colors">Pricing</a>
          </div>
          <InquiryDialog>
            <Button size="sm" className="font-semibold shadow-md shadow-primary/20">
              Get Started
            </Button>
          </InquiryDialog>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="pt-32 pb-20 md:pt-40 md:pb-32 px-4 relative overflow-hidden">
        {/* Abstract background blobs */}
        <div className="absolute top-0 right-0 -mr-20 -mt-20 w-96 h-96 bg-blue-100 rounded-full blur-3xl opacity-50 z-0"></div>
        <div className="absolute bottom-0 left-0 -ml-20 -mb-20 w-80 h-80 bg-green-100 rounded-full blur-3xl opacity-50 z-0"></div>
        
        <div className="container mx-auto max-w-6xl relative z-10">
          <motion.div 
            initial="initial"
            animate="animate"
            variants={staggerContainer}
            className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center"
          >
            <div className="space-y-8 text-center lg:text-left">
              <motion.div variants={fadeIn}>
                <Badge variant="outline" className="px-4 py-1.5 border-primary/20 text-primary bg-primary/5 rounded-full text-sm mb-6">
                  For Professional Holiday Let Owners
                </Badge>
                <h1 className="text-4xl md:text-5xl lg:text-6xl font-extrabold text-slate-900 leading-[1.15] text-balance">
                  Smarter pricing for your <span className="text-primary">holiday lets</span>
                </h1>
                <p className="mt-6 text-lg md:text-xl text-slate-600 leading-relaxed text-balance max-w-2xl mx-auto lg:mx-0">
                  Stop leaving money on the table with static rates. We combine human expertise with data-driven adjustments to maximize your revenue, all year round.
                </p>
              </motion.div>
              
              <motion.div variants={fadeIn} className="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                <InquiryDialog>
                  <Button size="lg" className="h-14 px-8 text-lg rounded-xl shadow-xl shadow-primary/20 hover:-translate-y-1 transition-transform">
                    Get a Free Pricing Review
                  </Button>
                </InquiryDialog>
                <Button variant="outline" size="lg" className="h-14 px-8 text-lg rounded-xl border-slate-300 hover:bg-slate-50" asChild>
                  <a href="#how-it-works">See How It Works</a>
                </Button>
              </motion.div>
              
              <motion.div variants={fadeIn} className="pt-4 flex items-center justify-center lg:justify-start gap-6 text-sm text-slate-500 font-medium">
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" /> No Setup Fees
                </div>
                <div className="flex items-center gap-2">
                  <Check className="w-4 h-4 text-green-500" /> Cancel Anytime
                </div>
              </motion.div>
            </div>

            <motion.div variants={fadeIn} className="relative hidden lg:block">
              <div className="relative z-10 rounded-2xl overflow-hidden shadow-2xl shadow-blue-900/10 border border-white/20">
                 {/* Modern analytics dashboard image */}
                 <img 
                  src="https://images.unsplash.com/photo-1551288049-bebda4e38f71?q=80&w=2070&auto=format&fit=crop" 
                  alt="Analytics Dashboard" 
                  className="w-full h-auto object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-slate-900/40 to-transparent"></div>
                <div className="absolute bottom-6 left-6 right-6">
                   <div className="bg-white/95 backdrop-blur rounded-xl p-4 shadow-lg flex items-center justify-between">
                      <div>
                        <div className="text-xs text-slate-500 uppercase font-bold tracking-wider">Revenue Uplift</div>
                        <div className="text-2xl font-bold text-slate-900">+24% vs. Last Year</div>
                      </div>
                      <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                        <TrendingUp className="w-6 h-6 text-green-600" />
                      </div>
                   </div>
                </div>
              </div>
              {/* Decorative elements */}
              <div className="absolute -top-6 -right-6 w-full h-full border-2 border-primary/10 rounded-2xl z-0"></div>
            </motion.div>
          </motion.div>
        </div>
      </section>

      {/* Who It's For */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4 text-center max-w-4xl">
           <h2 className="text-3xl md:text-4xl font-bold mb-6">Built for ambitious owners</h2>
           <p className="text-lg text-slate-600 mb-12">
             Whether you manage a pair of cottages or a growing portfolio of luxury apartments, 
             Revenue Guard is designed for owners with 2–20 properties who want professional yield management without the agency fees.
           </p>
           <div className="grid md:grid-cols-3 gap-8">
              {[
                { count: "2-5", label: "Growing Portfolio", desc: "Start optimizing early to fund your next acquisition." },
                { count: "6-15", label: "Established Business", desc: "Streamline operations and maximize yield across your portfolio." },
                { count: "16+", label: "Professional Operator", desc: "Advanced strategies for high-volume management." }
              ].map((item, i) => (
                <div key={i} className="bg-slate-50 p-6 rounded-2xl border border-slate-100 hover:border-primary/20 transition-colors">
                  <div className="text-4xl font-bold text-primary mb-2">{item.count}</div>
                  <div className="font-semibold text-slate-900 mb-2">{item.label}</div>
                  <p className="text-sm text-slate-500">{item.desc}</p>
                </div>
              ))}
           </div>
        </div>
      </section>

      {/* The Problem */}
      <section id="problem" className="py-24 bg-slate-50 relative">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Why "Set and Forget" is costing you money</h2>
            <p className="text-lg text-slate-600">
              Most owners are too busy to adjust prices daily. The result? 
              You're either priced too low and leaving money on the table, or priced too high and sitting empty.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <Card className="border-none shadow-lg shadow-slate-200/50">
              <CardHeader>
                <div className="w-12 h-12 bg-red-100 rounded-xl flex items-center justify-center mb-4">
                  <Clock className="w-6 h-6 text-red-600" />
                </div>
                <CardTitle>The Time Drain</CardTitle>
              </CardHeader>
              <CardContent className="text-slate-600">
                Constantly monitoring competitors, local events, and seasonal trends takes hours every week that you simply don't have.
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg shadow-slate-200/50">
              <CardHeader>
                <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mb-4">
                  <BarChart3 className="w-6 h-6 text-orange-600" />
                </div>
                <CardTitle>Inconsistent Occupancy</CardTitle>
              </CardHeader>
              <CardContent className="text-slate-600">
                Without dynamic adjustments, you miss out on last-minute bookings during quiet periods and sell out too cheaply during peaks.
              </CardContent>
            </Card>

            <Card className="border-none shadow-lg shadow-slate-200/50 md:col-span-2 lg:col-span-1">
              <CardHeader>
                <div className="w-12 h-12 bg-purple-100 rounded-xl flex items-center justify-center mb-4">
                  <LayoutDashboard className="w-6 h-6 text-purple-600" />
                </div>
                <CardTitle>The "Gut Feeling" Trap</CardTitle>
              </CardHeader>
              <CardContent className="text-slate-600">
                Guessing your rates based on what you "feel" is right often leads to emotional pricing decisions rather than data-driven ones.
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Our Solution */}
      <section className="py-24 bg-primary text-white overflow-hidden relative">
        <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-10"></div>
        <div className="container mx-auto px-4 max-w-6xl relative z-10">
          <div className="grid lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-3xl md:text-5xl font-bold mb-6">The Revenue Guard Advantage</h2>
              <p className="text-xl text-blue-100 mb-8 leading-relaxed">
                We're not just an algorithm. We are a managed service that combines powerful data tools with expert human oversight.
              </p>
              <ul className="space-y-6">
                {[
                  "Daily price adjustments based on real-time market data",
                  "Human review of all major pricing strategies",
                  "Optimization for both occupancy and average daily rate (ADR)",
                  "Seamless integration with your existing PMS"
                ].map((item, i) => (
                  <li key={i} className="flex items-start gap-3">
                    <div className="mt-1 w-6 h-6 rounded-full bg-blue-400/20 flex items-center justify-center border border-blue-300/30">
                      <Check className="w-4 h-4 text-blue-200" />
                    </div>
                    <span className="text-lg text-blue-50">{item}</span>
                  </li>
                ))}
              </ul>
              
              <div className="mt-12">
                 <InquiryDialog>
                   <Button size="lg" variant="secondary" className="h-14 px-8 text-primary font-bold bg-white hover:bg-blue-50">
                     See What You Could Earn
                   </Button>
                 </InquiryDialog>
              </div>
            </div>
            
            <div className="relative">
              {/* Abstract representation of automation */}
              <div className="relative z-10 bg-white/10 backdrop-blur-lg rounded-2xl p-8 border border-white/20 shadow-2xl">
                <div className="space-y-6">
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="text-sm font-medium text-blue-200">Local Event Detected</div>
                    <Badge className="bg-green-500 hover:bg-green-600">+15% Rate Adjustment</Badge>
                  </div>
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="text-sm font-medium text-blue-200">Competitor Occupancy High</div>
                    <Badge className="bg-green-500 hover:bg-green-600">+8% Rate Adjustment</Badge>
                  </div>
                  <div className="flex items-center justify-between border-b border-white/10 pb-4">
                    <div className="text-sm font-medium text-blue-200">Last Minute Vacancy</div>
                    <Badge className="bg-amber-500 hover:bg-amber-600">-10% Rate Adjustment</Badge>
                  </div>
                  <div className="flex items-center justify-between pt-2">
                     <div className="font-bold text-2xl">Projected Revenue</div>
                     <div className="font-bold text-2xl text-green-300">£4,250 <span className="text-sm font-normal text-blue-200">/mo</span></div>
                  </div>
                </div>
              </div>
              <div className="absolute -inset-4 bg-gradient-to-r from-blue-400 to-teal-400 opacity-30 blur-2xl rounded-full z-0"></div>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section id="how-it-works" className="py-24 bg-white">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-4">How it works</h2>
            <p className="text-slate-600 text-lg">Four simple steps to optimized revenue</p>
          </div>

          <div className="relative">
            {/* Connecting line for desktop */}
            <div className="hidden md:block absolute top-1/2 left-0 w-full h-0.5 bg-slate-100 -translate-y-1/2 z-0"></div>

            <div className="grid md:grid-cols-4 gap-8 relative z-10">
              {[
                { step: "01", title: "Review", desc: "We analyze your historical performance and local market." },
                { step: "02", title: "Strategy", desc: "We build a custom pricing strategy for each property." },
                { step: "03", title: "Connect", desc: "We link with your PMS or channel manager securely." },
                { step: "04", title: "Optimize", desc: "Daily adjustments begin. You watch revenue grow." },
              ].map((item, i) => (
                <div key={i} className="bg-white p-6 rounded-xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow text-center md:text-left">
                  <div className="inline-block md:block mb-4">
                    <span className="text-4xl font-black text-slate-100">{item.step}</span>
                  </div>
                  <h3 className="text-xl font-bold text-slate-900 mb-2">{item.title}</h3>
                  <p className="text-slate-600 text-sm">{item.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* What You Get */}
      <section className="py-20 bg-slate-50">
        <div className="container mx-auto px-4 max-w-4xl">
          <div className="bg-white rounded-3xl p-8 md:p-12 shadow-xl shadow-slate-200/50 border border-slate-100">
            <h3 className="text-2xl md:text-3xl font-bold mb-8 text-center">Everything you need to succeed</h3>
            <div className="grid md:grid-cols-2 gap-x-12 gap-y-6">
              {[
                "Dedicated Revenue Manager",
                "Weekly Market Analysis Reports",
                "Dynamic Minimum Stay Rules",
                "Event & Holiday Pricing Strategy",
                "Gap Night Filling Strategy",
                "Monthly Performance Review Call",
                "Competitor Rate Monitoring",
                "Direct Booking Strategy Support"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-5 h-5 rounded-full bg-green-100 flex items-center justify-center flex-shrink-0">
                    <Check className="w-3 h-3 text-green-600" />
                  </div>
                  <span className="text-slate-700 font-medium">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Pricing */}
      <section id="pricing" className="py-24 bg-white">
        <div className="container mx-auto px-4 max-w-6xl">
          <div className="text-center max-w-3xl mx-auto mb-16">
            <h2 className="text-3xl md:text-4xl font-bold mb-6">Simple, transparent pricing</h2>
            <p className="text-lg text-slate-600">
              No hidden commissions. Just a flat monthly fee per property.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Starter */}
            <Card className="border border-slate-200 shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
              <CardHeader>
                <CardTitle className="text-xl text-slate-900">Starter</CardTitle>
                <CardDescription>For new hosts</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-slate-900">£29</span>
                  <span className="text-slate-500">/mo/unit</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4 text-sm text-slate-600">
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Daily Price Updates</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Market Data Integration</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Email Support</li>
                </ul>
              </CardContent>
              <CardFooter>
                <InquiryDialog className="w-full">
                  <Button className="w-full" variant="outline">Choose Starter</Button>
                </InquiryDialog>
              </CardFooter>
            </Card>

            {/* Growth */}
            <Card className="border-2 border-primary shadow-xl scale-105 relative z-10 bg-white">
              <div className="absolute top-0 left-1/2 -translate-x-1/2 -translate-y-1/2 bg-primary text-white text-xs font-bold px-3 py-1 rounded-full uppercase tracking-wider">
                Most Popular
              </div>
              <CardHeader>
                <CardTitle className="text-xl text-primary">Growth</CardTitle>
                <CardDescription>For professional portfolios</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-slate-900">£49</span>
                  <span className="text-slate-500">/mo/unit</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4 text-sm text-slate-600">
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Everything in Starter</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Dedicated Revenue Manager</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Monthly Strategy Call</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Minimum Stay Optimization</li>
                </ul>
              </CardContent>
              <CardFooter>
                <InquiryDialog className="w-full">
                  <Button className="w-full bg-primary hover:bg-primary/90 text-white shadow-lg shadow-primary/20">Choose Growth</Button>
                </InquiryDialog>
              </CardFooter>
            </Card>

            {/* Pro */}
            <Card className="border border-slate-200 shadow-sm hover:shadow-lg transition-all hover:-translate-y-1">
              <CardHeader>
                <CardTitle className="text-xl text-slate-900">Pro</CardTitle>
                <CardDescription>For 15+ properties</CardDescription>
                <div className="mt-4">
                  <span className="text-4xl font-bold text-slate-900">Custom</span>
                </div>
              </CardHeader>
              <CardContent>
                <ul className="space-y-4 text-sm text-slate-600">
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Full Service Management</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Custom Reporting</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> Priority Support</li>
                  <li className="flex items-center gap-2"><Check className="w-4 h-4 text-primary" /> API Integration</li>
                </ul>
              </CardContent>
              <CardFooter>
                <InquiryDialog className="w-full">
                  <Button className="w-full" variant="outline">Contact Sales</Button>
                </InquiryDialog>
              </CardFooter>
            </Card>
          </div>
        </div>
      </section>

      {/* Why This Is Different */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-4 max-w-5xl">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="order-2 md:order-1">
               <h2 className="text-3xl font-bold mb-6">Why Revenue Guard is different</h2>
               <div className="space-y-8">
                 <div>
                   <h3 className="text-xl font-bold text-slate-900 mb-2">Managed vs. DIY</h3>
                   <p className="text-slate-600">Software tools give you data, but you still have to do the work. We do the work for you, making expert decisions daily.</p>
                 </div>
                 <div>
                   <h3 className="text-xl font-bold text-slate-900 mb-2">Human + Machine</h3>
                   <p className="text-slate-600">Algorithms can miss nuance. Our revenue managers catch what the bots miss—construction noise, local festivals, or listing-specific quirks.</p>
                 </div>
                 <div>
                   <h3 className="text-xl font-bold text-slate-900 mb-2">Total Alignment</h3>
                   <p className="text-slate-600">Our goal is simple: increase your revenue. If you earn more, we succeed. It's a true partnership.</p>
                 </div>
               </div>
            </div>
            <div className="order-1 md:order-2">
              <div className="bg-white p-8 rounded-2xl shadow-xl shadow-slate-200/50 border border-slate-100">
                 <div className="flex items-center gap-4 mb-8">
                   <div className="w-12 h-12 rounded-full bg-slate-100 overflow-hidden">
                     <img src="https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&h=150&fit=crop" alt="Profile" />
                   </div>
                   <div>
                     <div className="font-bold text-slate-900">Sarah Jenkins</div>
                     <div className="text-sm text-slate-500">Revenue Manager</div>
                   </div>
                 </div>
                 <div className="relative">
                   <div className="absolute -left-4 -top-4 text-6xl text-primary/10 font-serif">"</div>
                   <p className="text-lg text-slate-700 italic relative z-10">
                     I review my clients' rates every morning with coffee. Last week, I spotted a new conference in town that the algorithm missed and bumped rates by 40%. We sold out in 2 hours. That's the human difference.
                   </p>
                 </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-24 bg-slate-900 text-white text-center">
        <div className="container mx-auto px-4 max-w-3xl">
          <h2 className="text-3xl md:text-5xl font-bold mb-6">Ready to maximize your revenue?</h2>
          <p className="text-xl text-slate-300 mb-10">
            Get a free, no-obligation pricing review for your portfolio. We'll show you exactly where you're leaving money on the table.
          </p>
          <InquiryDialog>
            <Button size="lg" className="h-16 px-10 text-xl font-bold bg-primary hover:bg-primary/90 text-white rounded-xl shadow-xl shadow-primary/25 hover:scale-105 transition-all">
              Get Your Free Review <ArrowRight className="ml-2 w-6 h-6" />
            </Button>
          </InquiryDialog>
          <p className="mt-6 text-sm text-slate-400">Limited spots available for free reviews this month.</p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 bg-white border-t border-slate-100">
        <div className="container mx-auto px-4 text-center">
          <div className="flex items-center justify-center gap-2 mb-6">
            <div className="w-6 h-6 bg-primary rounded-md flex items-center justify-center">
              <TrendingUp className="text-white w-4 h-4" />
            </div>
            <span className="font-bold text-lg text-slate-900">Revenue Guard</span>
          </div>
          <p className="text-slate-500 text-sm mb-8">
            &copy; {new Date().getFullYear()} Revenue Guard. All rights reserved.
          </p>
          <div className="flex justify-center gap-6 text-sm text-slate-500">
            <a href="#" className="hover:text-primary">Privacy Policy</a>
            <a href="#" className="hover:text-primary">Terms of Service</a>
            <a href="#" className="hover:text-primary">Contact</a>
          </div>
        </div>
      </footer>
    </div>
  );
}
