"use client";

/**
 * Tailark Hero Section 9 style — centered headline, subtitle, single CTA, trust line.
 * Reference: https://21st.dev/tailark/hero-section-9/default (Tailark Dusk)
 */

type HeroSectionNineProps = {
  onRequestReview?: () => void;
};

export default function HeroSectionNine({ onRequestReview }: HeroSectionNineProps) {
  return (
    <section className="relative flex min-h-[90vh] flex-col items-center justify-center px-6 py-24 text-center md:py-32">
      {/* Soft gradient orbs — Tailark/21st.dev style */}
      <div
        className="pointer-events-none absolute inset-0 overflow-hidden"
        aria-hidden
      >
        <div className="absolute left-1/2 top-0 h-[480px] w-[800px] -translate-x-1/2 -translate-y-1/3 rounded-full bg-primary-600/20 blur-[120px]" />
        <div className="absolute bottom-0 left-1/4 h-[320px] w-[500px] rounded-full bg-accent-cyan/10 blur-[100px]" />
        <div className="absolute right-1/4 top-1/3 h-[280px] w-[400px] rounded-full bg-primary-500/15 blur-[80px]" />
      </div>

      <div className="relative z-10 mx-auto max-w-3xl">
        <h1 className="font-display text-4xl font-semibold leading-[1.15] tracking-tight text-white md:text-5xl lg:text-6xl">
          Smarter pricing for your holiday lets{" "}
          <span className="mt-2 block bg-gradient-to-r from-white via-accent-cyan-light to-primary-200 bg-clip-text text-transparent">
            with clear monthly results
          </span>
        </h1>
        <p className="mt-6 text-lg text-primary-200/90 md:text-xl">
          We manage your pricing strategy and send you a simple monthly report
          showing exactly what it earned you.
        </p>
        <div className="mt-10">
          {onRequestReview ? (
            <button
              type="button"
              onClick={onRequestReview}
              className="inline-flex items-center justify-center rounded-lg bg-white px-8 py-3.5 text-base font-semibold text-primary-900 shadow-lg transition hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-primary-900"
            >
              Get a Free Pricing Review
            </button>
          ) : (
            <a
              href="#cta"
              className="inline-flex items-center justify-center rounded-lg bg-white px-8 py-3.5 text-base font-semibold text-primary-900 shadow-lg transition hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-primary-900"
            >
              Get a Free Pricing Review
            </a>
          )}
        </div>
        <p className="mt-14 text-sm font-medium uppercase tracking-widest text-primary-400">
          Built for holiday let owners with 2–20 properties
        </p>
      </div>
    </section>
  );
}
