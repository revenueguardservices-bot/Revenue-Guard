"use client";

import { useState } from "react";
import HeroSectionNine from "./HeroSectionNine";
import FreeReviewModal from "./FreeReviewModal";
import FadeInSection from "./FadeInSection";
import Logo from "./Logo";
import HowItWorksAccordion from "./HowItWorksAccordion";

export default function HomeWithModal() {
  const [showModal, setShowModal] = useState(false);

  const openModal = () => setShowModal(true);
  const closeModal = () => setShowModal(false);

  return (
    <>
      <FreeReviewModal isOpen={showModal} onClose={closeModal} />

      <div className="min-h-screen">
        {/* Tailark-style nav — minimal, over dark hero */}
        <header className="sticky top-0 z-50 border-b border-white/10 bg-primary-900/80 backdrop-blur-md">
          <nav className="mx-auto flex max-w-6xl items-center justify-between px-6 py-4">
            <a href="#" className="flex-shrink-0">
              <Logo width={200} height={48} className="h-10 w-auto object-contain brightness-0 invert opacity-90 md:h-11" />
            </a>
            <div className="flex items-center gap-8">
              <a href="#how-it-works" className="text-sm font-medium text-primary-200 transition hover:text-white">
                How It Works
              </a>
              <a href="#pricing" className="text-sm font-medium text-primary-200 transition hover:text-white">
                Pricing
              </a>
              <button
                type="button"
                onClick={openModal}
                className="rounded-lg bg-white px-4 py-2 text-sm font-semibold text-primary-900 transition hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-primary-900"
              >
                Get a Free Pricing Review
              </button>
            </div>
          </nav>
        </header>

        {/* Hero Section 9 — centered, gradient headline, one CTA, trust line (21st.dev/tailark) */}
        <section className="relative overflow-hidden bg-primary-900">
          <HeroSectionNine onRequestReview={openModal} />
        </section>

        {/* Who it's for — Tailark minimal */}
        <section id="who-its-for" className="relative border-t border-neutral-200 bg-white px-6 py-24 md:py-28">
          <FadeInSection>
            <div className="mx-auto max-w-4xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                Who it&apos;s for
              </h2>
              <p className="mx-auto mt-5 max-w-2xl text-center text-lg text-neutral-600">
                Holiday let owners and small short-term rental businesses with 2–20 properties.
              </p>
              <div className="mt-12 grid gap-6 sm:grid-cols-3">
                {[
                  { title: "Holiday let owners", desc: "Whether you have a cottage, flat, or house" },
                  { title: "Short-term rental hosts", desc: "A few listings, one clear strategy" },
                  { title: "2–20 properties", desc: "The sweet spot for managed pricing" },
                ].map((item, i) => (
                  <div key={i} className="rounded-xl border border-neutral-200 bg-neutral-50/50 p-6 text-center transition hover:border-neutral-300 hover:shadow-sm">
                    <p className="font-display font-semibold text-primary-900">{item.title}</p>
                    <p className="mt-2 text-sm text-neutral-600">{item.desc}</p>
                  </div>
                ))}
              </div>
              <div className="mt-12 rounded-xl border border-neutral-200 bg-neutral-50/50 p-8 text-center">
                <p className="font-display font-semibold text-primary-900">Ideal if you:</p>
                <ul className="mt-4 space-y-2 text-neutral-700">
                  <li>Don&apos;t want to constantly tweak prices</li>
                  <li>Don&apos;t trust built-in &quot;smart pricing&quot; tools</li>
                  <li>Want clarity and control, not a black box</li>
                </ul>
              </div>
            </div>
          </FadeInSection>
        </section>

        {/* The problem — minimal list */}
        <section className="relative border-t border-neutral-100 bg-neutral-50/50 px-6 py-24 md:py-28">
          <FadeInSection delay={100}>
            <div className="mx-auto max-w-3xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                The problem
              </h2>
              <p className="mt-5 text-center text-lg text-neutral-600">Many owners run into the same frustrations.</p>
              <ul className="mt-12 space-y-4">
                {[
                  "Peak dates underpriced — you leave money on the table when demand is high.",
                  "Quiet periods overpriced — empty nights when a lower rate would have filled the calendar.",
                  "Too much time spent adjusting prices — manual changes that never feel quite right.",
                  "No clear insight into whether your pricing changes are actually working.",
                ].map((item, i) => (
                  <li key={i} className="flex gap-4 rounded-xl border border-neutral-200 bg-white p-5">
                    <span className="flex h-8 w-8 flex-shrink-0 items-center justify-center rounded-full bg-primary-100 text-sm font-semibold text-primary-700">{i + 1}</span>
                    <span className="text-neutral-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </FadeInSection>
        </section>

        {/* Our solution — minimal cards */}
        <section className="relative border-t border-neutral-100 bg-white px-6 py-24 md:py-28">
          <FadeInSection delay={100}>
            <div className="mx-auto max-w-3xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                Our solution
              </h2>
              <p className="mt-5 text-center text-lg text-neutral-600">We take the guesswork out of pricing so you can focus on your guests.</p>
              <div className="mt-12 space-y-4">
                {[
                  { title: "We manage pricing for you", desc: "No spreadsheets, no dashboards to learn. We handle the strategy; you get a clear report each month." },
                  { title: "Prices adjust automatically based on real demand", desc: "We use demand, seasonality, lead time, and availability — not one-size-fits-all rules." },
                  { title: "Guardrails protect your minimum and maximum rates", desc: "You set the boundaries. We never push prices below or above what you're comfortable with." },
                  { title: "A clear monthly report: what changed and why", desc: "Plain English, no jargon. You'll see how pricing changes affected revenue and what we recommend next." },
                ].map((item, i) => (
                  <div key={i} className="rounded-xl border border-neutral-200 bg-neutral-50/50 p-6 transition hover:border-neutral-300 hover:shadow-sm">
                    <p className="font-display font-semibold text-primary-900">{item.title}</p>
                    <p className="mt-2 text-sm leading-relaxed text-neutral-700">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </FadeInSection>
        </section>

        {/* How it works — accordion */}
        <section id="how-it-works" className="relative border-t border-neutral-100 bg-neutral-50/50 px-6 py-24 md:py-28">
          <FadeInSection delay={100}>
            <div className="mx-auto max-w-6xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                How it works
              </h2>
              <p className="mx-auto mt-4 max-w-2xl text-center text-lg text-neutral-600">
                Four simple steps from review to results. Hover or tap a step to expand.
              </p>
              <div className="mt-12 md:mt-14">
                <HowItWorksAccordion />
              </div>
            </div>
          </FadeInSection>
        </section>

        {/* What you get each month */}
        <section className="relative border-t border-neutral-100 bg-white px-6 py-24 md:py-28">
          <FadeInSection delay={100}>
            <div className="mx-auto max-w-3xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                What you get each month
              </h2>
              <ul className="mt-12 space-y-4">
                {[
                  "Automated price optimisation — rates that respond to demand without you doing anything",
                  "Occupancy and revenue insights — see how your properties are performing",
                  "Best and worst performing dates — so you know what's working",
                  "Clear recommendations for the month ahead",
                  "Optional monthly call on higher plans",
                ].map((item, i) => (
                  <li key={i} className="flex gap-4 rounded-xl border border-neutral-200 bg-neutral-50/50 px-5 py-4">
                    <span className="flex h-6 w-6 flex-shrink-0 items-center justify-center rounded-full bg-primary-600 text-sm font-bold text-white">✓</span>
                    <span className="text-neutral-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          </FadeInSection>
        </section>

        {/* Pricing — minimal cards */}
        <section id="pricing" className="relative border-t border-neutral-100 bg-neutral-50/50 px-6 py-24 md:py-28">
          <FadeInSection delay={100}>
            <div className="mx-auto max-w-5xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                Pricing
              </h2>
              <p className="mt-5 text-center text-lg text-neutral-600">Clear pricing. No hidden fees.</p>
              <div className="mt-14 grid gap-6 md:grid-cols-3">
                {[
                  { name: "Starter", price: "£199", for: "1–2 properties", features: ["Dynamic pricing", "Monthly performance report"], primary: false },
                  { name: "Growth", price: "£399", for: "3–5 properties", features: ["Everything in Starter", "Monthly review call"], primary: true },
                  { name: "Pro", price: "£699", for: "6–15 properties", features: ["Full portfolio pricing", "Priority support"], primary: false },
                ].map((plan) => (
                  <div
                    key={plan.name}
                    className={`relative flex flex-col rounded-xl border-2 bg-white p-6 transition md:p-7 ${
                      plan.primary ? "border-primary-600 shadow-lg" : "border-neutral-200 hover:border-neutral-300 hover:shadow-md"
                    }`}
                  >
                    {plan.primary && <span className="absolute -top-3 left-1/2 -translate-x-1/2 rounded-full bg-primary-600 px-4 py-1 text-xs font-semibold text-white">Popular</span>}
                    <h3 className="font-display font-semibold text-xl text-primary-900">{plan.name}</h3>
                    <p className="mt-3 text-2xl font-display font-semibold text-primary-800">{plan.price}<span className="text-base font-normal text-neutral-600">/month</span></p>
                    <p className="mt-2 text-sm text-neutral-600">For {plan.for}</p>
                    <ul className="mt-5 flex-1 space-y-3 text-sm text-neutral-700">
                      {plan.features.map((f, i) => (
                        <li key={i} className="flex gap-2">✓ {f}</li>
                      ))}
                    </ul>
                    <button
                      type="button"
                      onClick={openModal}
                      className={`mt-6 w-full rounded-lg py-3 font-semibold transition focus:outline-none focus:ring-2 focus:ring-primary-500 focus:ring-offset-2 ${
                        plan.primary ? "bg-primary-600 text-white hover:bg-primary-700" : "border-2 border-primary-600 text-primary-700 hover:bg-primary-50"
                      }`}
                    >
                      Get started
                    </button>
                  </div>
                ))}
              </div>
              <p className="mt-10 text-center text-sm text-neutral-600">No long-term contracts. Cancel anytime.</p>
            </div>
          </FadeInSection>
        </section>

        {/* Why this is different */}
        <section className="relative border-t border-neutral-100 bg-white px-6 py-24 md:py-28">
          <FadeInSection delay={100}>
            <div className="mx-auto max-w-4xl">
              <h2 className="font-display text-3xl font-semibold tracking-tight text-primary-900 md:text-4xl text-center">
                Why this is different
              </h2>
              <div className="mt-12 grid gap-6 sm:grid-cols-2">
                {[
                  { title: "Managed service, not a DIY tool", desc: "We do the work. You get the report." },
                  { title: "Clear explanations, not a black box", desc: "You'll understand what changed and why." },
                  { title: "Human oversight with automated execution", desc: "Technology handles the updates; people handle the strategy." },
                  { title: "Designed specifically for holiday lets", desc: "Built for your market, not generic short-term rental logic." },
                ].map((item, i) => (
                  <div key={i} className="rounded-xl border border-neutral-200 bg-neutral-50/50 p-6 transition hover:border-neutral-300 hover:shadow-sm">
                    <p className="font-display font-semibold text-primary-900">{item.title}</p>
                    <p className="mt-2 text-sm leading-relaxed text-neutral-700">{item.desc}</p>
                  </div>
                ))}
              </div>
            </div>
          </FadeInSection>
        </section>

        {/* Final CTA — Tailark-style dark strip */}
        <section id="cta" className="relative border-t border-primary-800 bg-primary-900 px-6 py-24 md:py-28 text-white">
          <div className="absolute inset-0 opacity-20" style={{ backgroundImage: "radial-gradient(ellipse 50% 50% at 50% 50%, rgba(255,255,255,0.08) 0%, transparent 70%)" }} />
          <FadeInSection delay={100}>
            <div className="relative mx-auto max-w-2xl text-center">
              <h2 className="font-display text-3xl font-semibold tracking-tight md:text-4xl">See if your pricing could be working harder</h2>
              <button
                type="button"
                onClick={openModal}
                className="mt-10 inline-flex items-center justify-center rounded-lg bg-white px-10 py-3.5 font-semibold text-primary-900 transition hover:bg-primary-50 focus:outline-none focus:ring-2 focus:ring-white/50 focus:ring-offset-2 focus:ring-offset-primary-900"
              >
                Request a Free Pricing Review
              </button>
              <p className="mt-5 text-sm text-primary-300">No obligation. No pressure.</p>
            </div>
          </FadeInSection>
        </section>

        {/* FOOTER */}
        <footer className="relative py-16 px-6 bg-primary-900 text-primary-100 overflow-hidden">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-primary-700 to-transparent opacity-50" />
          <div className="max-w-5xl mx-auto flex flex-col md:flex-row md:items-center md:justify-between gap-10">
            <div>
              <Logo width={200} height={48} className="h-11 md:h-12 w-auto object-contain brightness-0 invert opacity-90" />
              <p className="mt-3 text-sm text-primary-200 max-w-sm leading-relaxed">
                Managed dynamic pricing for holiday let owners. Smarter pricing. Clear results. Zero guesswork.
              </p>
            </div>
            <div className="flex flex-col sm:flex-row gap-6">
              <a href="#how-it-works" className="text-sm text-primary-200 hover:text-white transition-colors">How It Works</a>
              <a href="#pricing" className="text-sm text-primary-200 hover:text-white transition-colors">Pricing</a>
              <button type="button" onClick={openModal} className="text-sm text-primary-200 hover:text-white transition-colors text-left sm:text-left">
                Get a Free Pricing Review
              </button>
              <a href="mailto:revenueguardservices@gmail.com" className="text-sm text-primary-200 hover:text-white transition-colors">revenueguardservices@gmail.com</a>
            </div>
          </div>
          <p className="max-w-5xl mx-auto mt-10 pt-8 border-t border-primary-800 text-xs text-primary-300">
            © {new Date().getFullYear()} Revenue Guard LTD. All rights reserved.
          </p>
        </footer>
      </div>
    </>
  );
}
