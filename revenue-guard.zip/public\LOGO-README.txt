Logo: The site uses logo.png in the header and footer (with fallback to logo.svg if logo.png fails to load).
- Your Revenue Guard logo (shield + REVENUE GUARD text) is in public/logo.png.
- To replace: overwrite public/logo.png or public/logo.svg. The Logo component tries logo.png first, then logo.svg.

Colors: Edit app/globals.css — primary blues and accent-cyan match the logo; accent-orange-subtle is kept very subtle.
