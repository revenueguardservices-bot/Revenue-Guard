import type { Metadata } from "next";
import { Plus_Jakarta_Sans } from "next/font/google";
import "./globals.css";

const plusJakarta = Plus_Jakarta_Sans({
  subsets: ["latin"],
  variable: "--font-sans",
  display: "swap",
  weight: ["400", "500", "600", "700", "800"],
});

export const metadata: Metadata = {
  title: "Revenue Guard LTD — Smarter pricing. Clear results. Zero guesswork.",
  description:
    "Managed dynamic pricing for holiday let owners. We adjust your nightly prices based on demand and send you a simple monthly report showing exactly what it earned you.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" className="scroll-smooth">
      <body
        className={`${plusJakarta.variable} font-sans antialiased min-h-screen bg-neutral-50 text-neutral-900`}
      >
        {children}
      </body>
    </html>
  );
}
