"use client";

import { useEffect, useRef, useState } from "react";

type ScrollExpansionHeroProps = {
  onRequestReview?: () => void;
};

export default function ScrollExpansionHero({ onRequestReview }: ScrollExpansionHeroProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [scrollProgress, setScrollProgress] = useState(0);

  useEffect(() => {
    const container = containerRef.current;
    if (!container) return;

    const handleScroll = () => {
      const rect = container.getBoundingClientRect();
      const viewportHeight = window.innerHeight;
      // Progress 0 when hero top is at top of viewport; 1 when we've scrolled past the media
      const start = 0;
      const end = viewportHeight * 1.2;
      const scrolled = -rect.top;
      const progress = Math.min(1, Math.max(0, scrolled / end));
      setScrollProgress(progress);
    };

    window.addEventListener("scroll", handleScroll, { passive: true });
    handleScroll();
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  // Media expands: scale 0.75 -> 1, radius 32px -> 0, width constrained -> full
  const scale = 0.75 + scrollProgress * 0.25;
  const borderRadius = 32 - scrollProgress * 32;
  const opacity = 0.92 + scrollProgress * 0.08;

  return (
    <div ref={containerRef} className="relative">
      {/* Hero content — white text on dark (parent section is dark) */}
      <div className="relative z-10 min-h-[70vh] flex flex-col items-center justify-center px-6 pt-24 pb-16">
        <h1 className="font-display text-4xl md:text-5xl lg:text-6xl font-bold text-white leading-[1.1] tracking-tight text-center max-w-4xl drop-shadow-sm">
          Smarter pricing for your holiday lets — with clear monthly results
        </h1>
        <p className="mt-6 text-lg md:text-xl text-primary-100 max-w-2xl mx-auto text-center">
          We manage your pricing strategy and send you a simple monthly report
          showing exactly what it earned you.
        </p>
        <div className="mt-10 flex flex-col sm:flex-row gap-4 justify-center">
          {onRequestReview ? (
            <button
              type="button"
              onClick={onRequestReview}
              className="inline-flex items-center justify-center rounded-xl bg-accent-cyan text-white font-semibold px-8 py-4 hover:bg-accent-cyan-light transition-all duration-300 shadow-lg theme-btn-primary theme-focus-ring border-b-2 border-accent-orange/50"
            >
              Get a Free Pricing Review
            </button>
          ) : (
            <a
              href="#cta"
              className="inline-flex items-center justify-center rounded-xl bg-accent-cyan text-white font-semibold px-8 py-4 hover:bg-accent-cyan-light transition-all duration-300 shadow-lg theme-btn-primary theme-focus-ring"
            >
              Get a Free Pricing Review
            </a>
          )}
          <a
            href="#how-it-works"
            className="inline-flex items-center justify-center rounded-xl border-2 border-white/60 text-white font-semibold px-8 py-4 hover:bg-white/10 transition-all duration-300"
          >
            How It Works
          </a>
        </div>
      </div>

      {/* Expanding panel — light “window” on dark hero */}
      <div className="relative h-[85vh] flex items-center justify-center px-4 md:px-6 -mt-32">
        <div
          className="w-full max-w-5xl mx-auto h-[55vh] min-h-[320px] flex items-center justify-center overflow-hidden"
          style={{
            transform: `scale(${scale})`,
            transformOrigin: "center center",
          }}
        >
          <div
            className="w-full h-full relative rounded-3xl overflow-hidden shadow-2xl border-2 border-white/20 bg-white/95 backdrop-blur"
            style={{
              borderRadius: `${borderRadius}px`,
              opacity,
              boxShadow: "0 25px 50px -12px rgba(0,0,0,0.35), 0 0 0 1px rgba(255,255,255,0.1)",
            }}
          >
            <div className="absolute inset-0 bg-gradient-to-br from-primary-50 via-white to-primary-50/80" />
            <div className="absolute top-0 left-0 right-0 h-1 bg-gradient-to-r from-primary-600 via-accent-cyan to-primary-600" />
            <div className="absolute inset-0 flex items-center justify-center p-8 z-10">
              <div className="text-center">
                <p className="text-xs font-semibold uppercase tracking-widest text-primary-600">
                  Revenue Guard
                </p>
                <p className="mt-2 text-xl md:text-2xl font-display font-semibold text-primary-900 max-w-md">
                  Dynamic pricing that adapts to demand — so you don&apos;t have to
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
