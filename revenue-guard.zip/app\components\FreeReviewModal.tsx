"use client";

import { useEffect, useState } from "react";
import emailjs from "@emailjs/browser";

const REVIEW_EMAIL = "revenueguardservices@gmail.com";
const EMAIL_SUBJECT = "Free Pricing Review Request";

const SERVICE_ID = process.env.NEXT_PUBLIC_EMAILJS_SERVICE_ID;
const TEMPLATE_ID = process.env.NEXT_PUBLIC_EMAILJS_TEMPLATE_ID;
const PUBLIC_KEY = process.env.NEXT_PUBLIC_EMAILJS_PUBLIC_KEY;
const USE_EMAILJS = Boolean(SERVICE_ID && TEMPLATE_ID && PUBLIC_KEY);

type FreeReviewModalProps = {
  isOpen: boolean;
  onClose: () => void;
};

const PROPERTY_COUNT_OPTIONS = [
  { value: "1-2", label: "1-2 Properties" },
  { value: "3-5", label: "3-5 Properties" },
  { value: "6-15", label: "6-15 Properties" },
  { value: "16+", label: "16+ Properties" },
] as const;

function buildEmailBody(
  name: string,
  email: string,
  propertyCount: string,
  location: string,
  message: string
) {
  const lines = [
    `Name: ${name}`,
    `Email: ${email}`,
    `Number of properties: ${propertyCount || "—"}`,
    `Location: ${location || "—"}`,
    "",
    "Notes / message:",
    message || "—",
  ];
  return lines.join("\n");
}

export default function FreeReviewModal({ isOpen, onClose }: FreeReviewModalProps) {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [propertyCount, setPropertyCount] = useState("");
  const [location, setLocation] = useState("");
  const [message, setMessage] = useState("");
  const [status, setStatus] = useState<"idle" | "sending" | "success" | "error">("idle");
  const [errorMessage, setErrorMessage] = useState("");

  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    if (isOpen) {
      document.addEventListener("keydown", handleEscape);
      document.body.style.overflow = "hidden";
    }
    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus("sending");
    setErrorMessage("");

    const body = buildEmailBody(name, email, propertyCount, location, message);

    try {
      if (USE_EMAILJS && PUBLIC_KEY) {
        await emailjs.send(SERVICE_ID!, TEMPLATE_ID!, {
          to_email: REVIEW_EMAIL,
          subject: EMAIL_SUBJECT,
          from_name: name,
          reply_to: email,
          message: body,
        }, PUBLIC_KEY);
      } else {
        const subject = encodeURIComponent(EMAIL_SUBJECT);
        const bodyEnc = encodeURIComponent(body);
        window.location.href = `mailto:${REVIEW_EMAIL}?subject=${subject}&body=${bodyEnc}`;
      }
      setStatus("success");
      setName("");
      setEmail("");
      setPropertyCount("");
      setLocation("");
      setMessage("");
      setTimeout(() => {
        setStatus("idle");
        onClose();
      }, 2800);
    } catch (err) {
      setStatus("error");
      setErrorMessage(
        USE_EMAILJS
          ? "Could not send. Please email us directly at " + REVIEW_EMAIL
          : "Something went wrong. Please email us directly at " + REVIEW_EMAIL
      );
    }
  };

  const isSending = status === "sending";
  const isSuccess = status === "success";
  const isError = status === "error";

  if (!isOpen) return null;

  return (
    <div
      className="fixed inset-0 z-[100] flex items-center justify-center p-4"
      role="dialog"
      aria-modal="true"
      aria-labelledby="free-review-modal-title"
      aria-describedby="free-review-modal-desc"
    >
      <div
        className="absolute inset-0 bg-neutral-900/60 backdrop-blur-sm"
        onClick={onClose}
        aria-hidden="true"
      />

      <div
        className="relative w-full max-w-md rounded-2xl bg-white shadow-2xl border border-neutral-200 overflow-hidden animate-fade-in-up theme-card max-h-[90vh] overflow-y-auto"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="p-6 md:p-8">
          <div className="flex items-center justify-between mb-6">
            <h2
              id="free-review-modal-title"
              className="font-display text-xl md:text-2xl font-semibold text-slate-900"
            >
              Get a Free Pricing Review
            </h2>
            <button
              type="button"
              onClick={onClose}
              className="p-2 rounded-lg text-neutral-500 hover:text-neutral-700 hover:bg-neutral-100 transition-colors theme-focus-ring"
              aria-label="Close"
            >
              <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>

          <p id="free-review-modal-desc" className="text-slate-600 text-base mb-6">
            See if your pricing could be working harder. No obligation. No pressure.
          </p>

          {isSuccess ? (
            <div className="py-8 text-center">
              <div className="w-12 h-12 rounded-full bg-primary-100 text-primary-600 flex items-center justify-center mx-auto mb-4">
                <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </div>
              <p className="text-primary-700 font-medium">
                {USE_EMAILJS ? "Request received. Thank you." : "Thanks! Check your email client to send."}
              </p>
              <p className="mt-2 text-sm text-neutral-600">We&apos;ll be in touch soon.</p>
            </div>
          ) : isError ? (
            <div className="py-6 text-center">
              <p className="text-red-600 font-medium">Could not open email</p>
              <p className="mt-2 text-sm text-neutral-600">{errorMessage}</p>
              <a
                href={`mailto:${REVIEW_EMAIL}`}
                className="mt-4 inline-block rounded-xl bg-primary-600 text-white font-medium px-6 py-2.5 hover:bg-primary-700 transition-colors"
              >
                Open email
              </a>
              <button
                type="button"
                onClick={() => { setStatus("idle"); setErrorMessage(""); }}
                className="mt-3 block w-full text-sm text-neutral-500 hover:text-neutral-700"
              >
                Try again
              </button>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-5">
              <div>
                <label htmlFor="free-review-name" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Full Name
                </label>
                <input
                  id="free-review-name"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  required
                  disabled={isSending}
                  className="w-full rounded-xl border border-neutral-300 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none transition disabled:opacity-60 theme-focus-ring h-11"
                  placeholder="John Doe"
                />
              </div>
              <div>
                <label htmlFor="free-review-email" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Email Address
                </label>
                <input
                  id="free-review-email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                  disabled={isSending}
                  className="w-full rounded-xl border border-neutral-300 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none transition disabled:opacity-60 theme-focus-ring h-11"
                  placeholder="john@example.com"
                />
              </div>
              <div>
                <label htmlFor="free-review-properties" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Number of Properties
                </label>
                <select
                  id="free-review-properties"
                  value={propertyCount}
                  onChange={(e) => setPropertyCount(e.target.value)}
                  required
                  disabled={isSending}
                  className="w-full rounded-xl border border-neutral-300 px-4 py-3 text-neutral-900 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none transition disabled:opacity-60 theme-focus-ring h-11 bg-white"
                >
                  <option value="">Select property count</option>
                  {PROPERTY_COUNT_OPTIONS.map((opt) => (
                    <option key={opt.value} value={opt.value}>{opt.label}</option>
                  ))}
                </select>
              </div>
              <div>
                <label htmlFor="free-review-location" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Location (optional)
                </label>
                <input
                  id="free-review-location"
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  disabled={isSending}
                  className="w-full rounded-xl border border-neutral-300 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none transition disabled:opacity-60 theme-focus-ring h-11"
                  placeholder="e.g. Cornwall, Lake District"
                />
              </div>
              <div>
                <label htmlFor="free-review-message" className="block text-sm font-medium text-slate-700 mb-1.5">
                  Notes / message (optional)
                </label>
                <textarea
                  id="free-review-message"
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  disabled={isSending}
                  rows={4}
                  className="w-full rounded-xl border border-neutral-300 px-4 py-3 text-neutral-900 placeholder-neutral-400 focus:border-primary-500 focus:ring-2 focus:ring-primary-500/20 outline-none transition disabled:opacity-60 resize-none theme-focus-ring min-h-[100px]"
                  placeholder="e.g. Struggling with winter occupancy..."
                />
              </div>
              <button
                type="submit"
                disabled={isSending}
                className="w-full h-12 text-base font-semibold bg-primary-600 hover:bg-primary-700 text-white rounded-lg shadow-lg shadow-primary-600/20 transition-all hover:scale-[1.02] disabled:opacity-70 disabled:cursor-not-allowed theme-focus-ring"
              >
                {isSending ? (
                  <>
                    <span className="inline-block w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin mr-2 align-middle" />
                    Sending...
                  </>
                ) : (
                  "Send"
                )}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
}
