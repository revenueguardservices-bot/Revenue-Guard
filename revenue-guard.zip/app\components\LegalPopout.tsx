"use client";

import { useEffect } from "react";
import {
  TERMS_TITLE,
  TERMS_UPDATED,
  TERMS_FOOTER,
  termsSections,
  PRIVACY_TITLE,
  PRIVACY_UPDATED,
  privacySections,
  COOKIE_TITLE,
  COOKIE_UPDATED,
  cookieSections,
} from "./legalContent";

export type LegalDocType = "terms" | "privacy" | "cookies";

type LegalPopoutProps = {
  type: LegalDocType | null;
  onClose: () => void;
};

function Section({ heading, body }: { heading: string; body: string }) {
  return (
    <div className="mb-6">
      <h3 className="text-base font-semibold text-[var(--foreground)] mb-2">{heading}</h3>
      <p className="text-sm text-[var(--muted)] leading-relaxed whitespace-pre-line">{body}</p>
    </div>
  );
}

export default function LegalPopout({ type, onClose }: LegalPopoutProps) {
  const isOpen = Boolean(type);

  useEffect(() => {
    if (!isOpen) return;
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    document.addEventListener("keydown", handleEscape);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleEscape);
      document.body.style.overflow = "";
    };
  }, [isOpen, onClose]);

  if (!type) return null;

  let title = "";
  let updated = "";
  let sections: { heading: string; body: string }[] = [];
  let footer: string | null = null;

  if (type === "terms") {
    title = TERMS_TITLE;
    updated = TERMS_UPDATED;
    sections = termsSections;
    footer = TERMS_FOOTER;
  } else if (type === "privacy") {
    title = PRIVACY_TITLE;
    updated = PRIVACY_UPDATED;
    sections = privacySections;
  } else if (type === "cookies") {
    title = COOKIE_TITLE;
    updated = COOKIE_UPDATED;
    sections = cookieSections;
  }

  return (
    <>
      <div
        className="fixed inset-0 z-[90] bg-black/40 backdrop-blur-sm transition-opacity duration-300"
        style={{ opacity: isOpen ? 1 : 0, pointerEvents: isOpen ? "auto" : "none" }}
        onClick={onClose}
        aria-hidden="true"
      />
      <div
        role="dialog"
        aria-modal="true"
        aria-labelledby="legal-popout-title"
        className="fixed bottom-0 left-0 right-0 z-[95] bg-white border-t-2 border-[var(--primary-200)] shadow-2xl rounded-t-2xl transition-transform duration-300 ease-out flex flex-col"
        style={{
          maxHeight: "85vh",
          transform: isOpen ? "translateY(0)" : "translateY(100%)",
        }}
      >
        <div className="sticky top-0 z-10 flex items-center justify-between px-4 py-4 bg-white border-b border-[var(--border)] rounded-t-2xl shrink-0">
          <div>
            <h2 id="legal-popout-title" className="text-lg font-bold text-[var(--foreground)]">
              {title}
            </h2>
            <p className="text-xs text-[var(--muted)] mt-0.5">Revenue Guard · Last updated: {updated}</p>
          </div>
          <button
            type="button"
            onClick={onClose}
            className="p-2 rounded-lg text-[var(--muted)] hover:text-[var(--foreground)] hover:bg-[var(--primary-50)] transition-colors theme-focus-ring"
            aria-label="Close"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        <div className="overflow-y-auto flex-1 px-4 py-6 pb-10">
          <div className="max-w-2xl mx-auto">
            {sections.map((section, i) => (
              <Section key={i} heading={section.heading} body={section.body} />
            ))}
            {footer && (
              <div className="mt-8 pt-6 border-t border-[var(--border)]">
                <p className="text-sm text-[var(--muted)] italic max-w-xl">{footer}</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </>
  );
}
